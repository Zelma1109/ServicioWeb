﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OperadorPrueba1._3 
{
    public class Secc
    {
        public static int id, idroll;
        public static string usuario;
    }
}